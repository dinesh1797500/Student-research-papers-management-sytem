//
//  SplashScreenViewController.swift
//  Student Research Paper Management System
//
//  Created by SAIL on 30/01/25.
//

import UIKit

class SplashScreenViewController: UIViewController {

    
    @IBOutlet weak var join: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Additional setup after loading the view
    }
    
    override func viewWillAppear(_animated:Bool){
    }
    
    @IBAction func log(_ sender: Any) {
        if let loginVc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
            self.navigationController?.pushViewController(loginVc, animated: true)
    }
    
}
}
