//
//  ViewController.swift
//  student research paper management system
//
//  Created by SAIL on 29/01/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}
