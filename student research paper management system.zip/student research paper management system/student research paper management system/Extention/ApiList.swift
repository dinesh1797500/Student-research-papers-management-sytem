//
//  ApiList.swift
//  student research paper management system
////  Created by SAIL on 13/02/25.
//

import  UIKit
import Foundation

struct ApiList {
    static let baseUrl = "http://localhost/srm/"
    static let listEnrollUrl = baseUrl + "student_enrolled.php"
    static let listSubmitUrl = baseUrl + "list_submited.php"
    static let signUpUrl = baseUrl + "signup.php"
    static let loginUrl = baseUrl + "login.php"
    static let student_enrolledURL = baseUrl + "student_enrolled.php"
    static let forgot_password = baseUrl + "forgot_password.php"
    static let class_list = baseUrl + "class_list.php"
    static let submissionURL = baseUrl + "add_submission.php"
    static let assignmentURL = baseUrl + "add_assignment.php"
    static let viewAssignmentURL = baseUrl + "Viewassignmentcontroller.php?id="
    static let profileURL = baseUrl + "view_profile.php"
    static let updateProfileURL = baseUrl + "update_profile.php"
    static let profile_image = baseUrl + "profile_image.php"
    static let codeURL = baseUrl + "enrollement.php"
    static let createClassURL = baseUrl + "create_class.php"
    static let assignmentsURL = baseUrl + "classroom_marks.php?id="
    static let studentMarksURL = baseUrl + "student_marks.php?id="
    static let assignmentListURL = baseUrl + "list_assignment.php"
}



class Constants {
    static var loginResponse : LoginModel?
}
struct APIConstants {
    static let baseUrl = "https://yourserver.com/" 
    static let assignmentListURL = baseUrl + "list_assignment.php"
}


class Utils {
    
    class func showAlert(on viewController: UIViewController,
                   title: String,
                   message: String,
                   actions: [UIAlertAction] = [UIAlertAction(title: "OK", style: .default, handler: nil)]) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        for action in actions {
            alertController.addAction(action)
        }
        viewController.present(alertController, animated: true, completion: nil)
    }
}

