//
//  EnrolledclassesModel.swift
//  student research paper management system
//
//  Created by SAIL on 25/02/25.
//

import Foundation

// MARK: - EnrollementListModel
struct EnrolledclassesModel: Codable {
    let status: Bool
    let message: String
    let data: [classes]
}

// MARK: - Datum
struct classes: Codable {
    let classroomID: Int
    let className: String

    enum CodingKeys: String, CodingKey {
        case classroomID = "classroom_id"
        case className = "class_name"
    }
}
