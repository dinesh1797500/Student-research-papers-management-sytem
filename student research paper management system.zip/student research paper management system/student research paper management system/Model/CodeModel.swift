//
//  CodeModel.swift
//  student research paper management system
//
//  Created by SAIL on 24/02/25.
//

import Foundation

// MARK: - CodeModel
struct CodeModel: Codable {
    let status: Bool
    let message: String
    let data: DataClass
}

// MARK: - DataClass
struct DataClass: Codable {
    let studentID, classroomID: Int
    let joinedAt: String

    enum CodingKeys: String, CodingKey {
        case studentID = "student_id"
        case classroomID = "classroom_id"
        case joinedAt = "joined_at"
    }
}
