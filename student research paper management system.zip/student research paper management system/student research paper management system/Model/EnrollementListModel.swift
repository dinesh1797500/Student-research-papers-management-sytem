//
//  EnrollementListModel.swift
//  student research paper management system
//
//  Created by SAIL on 13/02/25.
//

import Foundation

struct EnrollementListModel: Codable {
    let status: Bool
    let message: String
    let data: [EnrollementListData]
}

struct EnrollementListData: Codable {
    let id: Int
    let name, email, phone: String
}
