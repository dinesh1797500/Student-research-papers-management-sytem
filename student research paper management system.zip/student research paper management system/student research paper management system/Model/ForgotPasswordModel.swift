import Foundation

// MARK: - AddAssignment
struct ForgotPasswordModel: Codable {
    let status, message: String
    let data: ForgotPasswordData

    enum CodingKeys: String, CodingKey {
        case status = "Status"
        case message = "Message"
        case data = "Data"
    }
}

// MARK: - DataClass
struct ForgotPasswordData: Codable {
    let id: Int
    let name, email, updatedPassword: String

    enum CodingKeys: String, CodingKey {
        case id, name, email
        case updatedPassword = "updated_password"
    }
}
