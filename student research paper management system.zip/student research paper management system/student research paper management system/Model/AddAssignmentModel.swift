//
//  AddAssignmentModel.swift
//  student research paper management system
//
//  Created by SAIL on 19/02/25.
//


import Foundation

// MARK: - AddAssignmentModel
struct AddAssignmentModel: Codable {
    let status: Bool
    let message, assignmentID: String

    enum CodingKeys: String, CodingKey {
        case status, message
        case assignmentID = "assignment_id"
    }
}

