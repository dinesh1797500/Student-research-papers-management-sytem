//
//  SubmitListModel.swift
//  student research paper management system
//
//  Created by SAIL on 13/02/25.
//

import Foundation

// MARK: - SubmitListModel
struct SubmitListModel: Codable {
    let status: Bool
    let message: String
    let data: [SubmitListData]
}

struct SubmitListData: Codable {
    let submissionID, studentID: Int
    let name, email, submittedAt: String
    let marks: Int?

    enum CodingKeys: String, CodingKey {
        case submissionID = "submission_id"
        case studentID = "student_id"
        case name, email
        case submittedAt = "submitted_at"
        case marks
    }
}
