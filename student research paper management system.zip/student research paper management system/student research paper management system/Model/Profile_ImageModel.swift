//
//  Profile_ImageModel.swift
//  student research paper management system
//
//  Created by SAIL on 24/02/25.
//

import Foundation

// MARK: - ProfileImage
struct ProfileImage: Codable {
    let status: Bool
    let message: String
    let imageURL: String

    enum CodingKeys: String, CodingKey {
        case status, message
        case imageURL = "image_url"
    }
}
