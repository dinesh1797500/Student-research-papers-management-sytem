//
//  AssignmentListModel.swift
//  student research paper management system
//
//  Created by SAIL on 14/02/25.
//

import Foundation

// MARK: - AssignmentListModel
struct AssignmentListModel: Codable {
    let status: Bool
    let message: String
    let data: [String]
}
