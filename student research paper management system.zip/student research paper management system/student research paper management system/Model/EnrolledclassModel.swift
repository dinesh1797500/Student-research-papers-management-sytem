//
//  EnrolledclassModel.swift
//  student research paper management system
//
//  Created by SAIL on 18/02/25.
//


import Foundation

// MARK: - EnrolledclassModel
struct EnrolledclassModel: Codable {
    let status: Bool
    let message: String
    let data: enrolledClass
}

// MARK: - DataClass
struct enrolledClass: Codable {
    let id, classroomID: Int

    enum CodingKeys: String, CodingKey {
        case id
        case classroomID = "classroom_id"
    }
}

