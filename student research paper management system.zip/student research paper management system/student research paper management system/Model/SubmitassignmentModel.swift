//
//  SubmitassignmentModel.swift
//  student research paper management system
//
//  Created by SAIL on 19/02/25.
//

import Foundation

// MARK: - SubmitAssignment
struct SubmitassignmentModel: Codable {
    let status: Bool
    let message: String
    let data: submitClass
}

// MARK: - DataClass
struct submitClass: Codable {
    let submissionID: Int

    enum CodingKeys: String, CodingKey {
        case submissionID = "submission_id"
    }
}
