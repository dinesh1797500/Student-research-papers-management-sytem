//
//  LoginFile.swift
//  student research paper management system
//
//  Created by SAIL on 17/02/25.
//

import Foundation

// MARK: - LoginModel
struct LoginModel: Codable {
    let status: Bool
    let message: String
    let data: [logindata]
}

// MARK: - Datum
struct logindata: Codable {
    let id: Int
    let name, email, role: String
}
