//
//  AssignmentModel.swift
//  student research paper management system
//
//  Created by SAIL on 26/02/25.
//


import Foundation

struct AssignmentModel: Codable {
    let status: Bool
    let message: String
    let data: [Assignment]
}

// MARK: - Datum
struct Assignment: Codable {
    let assignmentID: String
    let marks: Int

    enum CodingKeys: String, CodingKey {
        case assignmentID = "assignment_id"
        case marks
    }
}
