//
//  ViewProfileModel.swift
//  student research paper management system
//
//  Created by SAIL on 20/02/25.
//
import Foundation

// MARK: - ViewProfileModel
struct ViewProfileModel: Codable {
    let status: Bool
    let message: String
    let data: UserProfile
}

// MARK: - DataClass
struct UserProfile: Codable {
    let id: Int
    let name, role, phone, email: String
    let profileImage: String
    let password: String

    enum CodingKeys: String, CodingKey {
        case id, name, role, phone, email
        case profileImage = "profile_image"
        case password
    }
}
