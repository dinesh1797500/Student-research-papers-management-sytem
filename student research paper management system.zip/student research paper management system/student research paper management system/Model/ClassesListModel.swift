//
//  File.swift
//  student research paper management system
//
//  Created by SAIL on 14/02/25.
//



import Foundation

// MARK: - Classlist
struct Classlist: Codable {
    let status: Bool
    let message: String
    let data: [classlistdata]
}

// MARK: - Datum
struct classlistdata: Codable {
    let sNo, id, classroomID: Int
    let className, classCode: String

    enum CodingKeys: String, CodingKey {
        case sNo = "s_no"
        case id
        case classroomID = "classroom_id"
        case className = "class_name"
        case classCode = "class_code"
    }
}
