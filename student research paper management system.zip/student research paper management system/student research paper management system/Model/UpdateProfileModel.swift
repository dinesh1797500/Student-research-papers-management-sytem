//
//  UpdateProfileModel.swift
//  student research paper management system
//
//  Created by SAIL on 20/02/25.
//

import Foundation

// MARK: - UpdateProfile
struct UpdateProfileModel: Codable {
    let status: Bool
    let message: String
    let data: dataClass
}

// MARK: - DataClass
struct dataClass: Codable {
    let id: Int
    let name, role, phone, email: String
}
