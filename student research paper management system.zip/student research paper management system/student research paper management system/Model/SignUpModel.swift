//
//  SignUpModel.swift
//  student research paper management system
//
//  Created by SAIL on 17/02/25.
//

import Foundation

struct SignUpModel: Codable {
    let status: Bool
    let message: String
    let data: [SignUpData]
}

// MARK: - Datum
struct SignUpData: Codable {
    let id: Int
    let name, role, phone, email: String
    let password, confirmPassword: String

    enum CodingKeys: String, CodingKey {
        case id, name, role, phone, email, password
        case confirmPassword = "confirm_password"
    }
}
