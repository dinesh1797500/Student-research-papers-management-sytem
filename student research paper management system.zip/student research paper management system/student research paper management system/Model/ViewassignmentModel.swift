//
//  ViewassignmentModel.swift
//  student research paper management system
//
//  Created by SAIL on 19/02/25.
//

import Foundation

// MARK: - AddAssignment
struct ViewassignmentModel: Codable {
    let status: Bool
    let message: String
    let data: ViewDataClass
}

// MARK: - DataClass
struct ViewDataClass: Codable {
    let id: Int
    let title, description: String
    let file: String
}

