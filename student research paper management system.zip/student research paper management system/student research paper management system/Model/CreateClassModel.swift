//
//  CreateClassModel.swift
//  student research paper management system
//
//  Created by SAIL on 24/02/25.
//
import Foundation

// MARK: - Classlist
struct CreateClassModel: Codable {
    let status: Bool
    let message: String
    let data: CreateClass
}

// MARK: - DataClass
struct CreateClass: Codable {
    let classroomID: Int
    let className, classCode: String

    enum CodingKeys: String, CodingKey {
        case classroomID = "classroom_id"
        case className = "class_name"
        case classCode = "class_code"
    }
}

