import UIKit

class CreateclassViewController: UIViewController {
    
    @IBOutlet weak var classname: UITextField!
    @IBOutlet weak var id: UITextField!
    @IBOutlet weak var code: UITextField!
    @IBOutlet weak var create: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func create(_ sender: Any) {
        guard let className = classname.text, !className.isEmpty,
              let teacherID = id.text, !teacherID.isEmpty,
              let classCode = code.text, !classCode.isEmpty else {
            showAlert(title: "Error", message: "All fields are required.")
            return
        }

        let classroomID = Int.random(in: 1000...9999) // Generate a random ID

        createClass(classroomID: classroomID, className: className, teacherID: teacherID, classCode: classCode)
    }

    func createClass(classroomID: Int, className: String, teacherID: String, classCode: String) {
        guard let url = URL(string: ApiList.createClassURL) else {
            print(" Error: Invalid API URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        let postString = "id=\(teacherID)&classroom_id=\(classroomID)&class_name=\(className)&class_code=\(classCode)"
        request.httpBody = postString.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print(" API Error: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    self.showAlert(title: "Error", message: "Failed to create class. Try again.")
                }
                return
            }

            guard let data = data else {
                print(" Error: No data received from API")
                return
            }

            do {
                let decodedResponse = try JSONDecoder().decode(CreateClassModel.self, from: data)
                DispatchQueue.main.async {
                    if decodedResponse.status {
                        self.showAlert(title: "Success", message: decodedResponse.message) {
                            let homeVC = self.storyboard?.instantiateViewController(withIdentifier: "TeacherHomeViewController") as! TeacherHomeViewController
                            self.navigationController?.pushViewController(homeVC, animated: true)
                        }
                    } else {
                        self.showAlert(title: "Error", message: decodedResponse.message)
                    }
                }
            } catch {
                print(" Decoding Error: \(error.localizedDescription)")
                print(" Raw Response: \(String(data: data, encoding: .utf8) ?? "Invalid Data")")
            }
        }
        task.resume()
    }

    // Utility function to show alerts
    func showAlert(title: String, message: String, completion: (() -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
            completion?()
        })
        present(alert, animated: true)
    }
}
