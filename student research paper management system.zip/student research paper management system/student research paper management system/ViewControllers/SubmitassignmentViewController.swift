//
//  SubmitassignmentViewController.swift
//  student research paper management system
//
//  Created by SAIL on 19/02/25.
//
import UIKit
import UniformTypeIdentifiers

class SubmitassignmentViewController: UIViewController, UIDocumentPickerDelegate {

    @IBOutlet weak var Assign: UIButton!
    @IBOutlet weak var DescriptionTextfeild: UITextField!
    @IBOutlet weak var TitleTextfeild: UITextField!
    @IBOutlet weak var UploadButton: UIButton!
    
    @IBOutlet weak var dateTF: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    @IBAction func Assign(_ sender: Any) {
        let joinVC = (self.storyboard?.instantiateViewController(withIdentifier: "AssignmentViewController") as? AssignmentViewController)!
        self.navigationController?.pushViewController(joinVC, animated: true)
    }
    @IBAction func Upload(_ sender: Any) {
        openDocumentPicker()
    }
    func openDocumentPicker() {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.pdf])
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        present(documentPicker, animated: true)
    }
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let selectedFileURL = urls.first else { return }
        print("Selected PDF URL: \(selectedFileURL)")
        
    }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("User cancelled document picker")
    }
    @IBAction func dateBtnTapped(_ sender: Any) {
    }
}

