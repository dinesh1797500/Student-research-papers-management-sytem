//
//  NewViewController.swift
//  student research paper management system
//
//  Created by SAIL on 17/02/25.
//

import UIKit

class NewViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
    }
    

    

}
