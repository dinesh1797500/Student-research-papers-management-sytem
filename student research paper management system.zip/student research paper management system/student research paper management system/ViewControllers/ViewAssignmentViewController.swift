//
//  ViewAssignmentViewController.swift
//  student research paper management system
//
//  Created by SAIL on 17/02/25.
//

import UIKit
import WebKit

class ViewAssignmentViewController: UIViewController {
    
    @IBOutlet weak var submitBt: UIButton!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    var idData = "11"
    var pdfData = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchApi()
    }
    
    @IBAction func fileButtonTapped(_ sender: Any) {
        guard let url = URL(string: pdfData) else {
            Utils.showAlert(on: self, title: "Error", message: "Invalid PDF URL")
            return
        }
        
        let webViewVC = UIViewController()
        let webView = WKWebView(frame: webViewVC.view.bounds)
        webViewVC.view.addSubview(webView)
        
        webView.load(URLRequest(url: url))
        
        navigationController?.pushViewController(webViewVC, animated: true)
    }
    
    @IBAction func submitBt(_ sender: Any) {
        guard let joinVC = storyboard?.instantiateViewController(withIdentifier: "uploadViewController") as? uploadViewController else { return }
        navigationController?.pushViewController(joinVC, animated: true)
    }
}

extension ViewAssignmentViewController {
    func fetchApi() {
        APIHandler.shared.getAPIValues(type: ViewassignmentModel.self, apiUrl: ApiList.viewAssignmentURL + idData, method: "GET") { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let data):
                    if data.status {
                        self.nameLabel.text = data.data.title
                        self.descriptionLabel.text = data.data.description
                        self.pdfData = ApiList.baseUrl + data.data.file
                        print(self.pdfData)
                    } else {
                        Utils.showAlert(on: self, title: "", message: data.message)
                    }
                case .failure(let error):
                    print(error.localizedDescription)
                    Utils.showAlert(on: self, title: "Failure", message: error.localizedDescription)
                }
            }
        }
    }
}
