//
//  SignUpViewController.swift
//  student research paper management system
//
//  Created by SAIL on 14/02/25.
//

import UIKit

class SignUpViewController: UIViewController {

    @IBOutlet weak var signup: UIButton!
    @IBOutlet weak var signupBtn: UIButton!
    @IBOutlet weak var confirmPassTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var phoneTF: UITextField!
    @IBOutlet weak var roleTF: UITextField!
    @IBOutlet weak var nameTF: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func signupBtnTapped(_ sender: Any) {
        postApi(name: nameTF.text ?? "", role: roleTF.text ?? "", phone: phoneTF.text ?? "", email: emailTF.text ?? "", password: passwordTF.text ?? "", confirmPassword: confirmPassTF.text ?? "")
        
    }
    
    @IBAction func signup(_ sender: Any) {
        let joinVC = (self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController)!
        self.navigationController?.pushViewController(joinVC, animated: true)
        
    }
    

}
extension SignUpViewController {
    func postApi(name: String, role: String, phone: String, email: String, password : String, confirmPassword: String){
            let param = ["name": name,"role": role,"phone": phone,"email": email,"password": password,"confirm_password": confirmPassword]
        
              APIHandler.shared.postAPIValues(type: SignUpModel.self, apiUrl: ApiList.signUpUrl, method: "POST", formData: param) { result in
                switch result {
                case .success(let response):
                    DispatchQueue.main.async {
                        if response.status {
                            let SignupVC = (self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController)!
                            self.navigationController?.pushViewController(SignupVC, animated: true)
                        }else{
                            Utils.showAlert(on: self, title: "", message: response.message)
                        }
                    }
                case .failure(let err):
                    print(err)
                    Utils.showAlert(on: self, title: "", message: "Error fetching enrollment data")
                }
            }
        }
}
