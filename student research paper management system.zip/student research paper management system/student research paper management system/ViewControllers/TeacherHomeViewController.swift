import UIKit

class TeacherHomeViewController: UIViewController {
    
    @IBOutlet weak var create: UIButton!
    @IBOutlet weak var profile: UIButton!
    @IBOutlet weak var listTableview: UITableView! {
        didSet {
            listTableview.delegate = self
            listTableview.dataSource = self
            listTableview.register(UINib(nibName: "ClassListTableViewCell", bundle: nil), forCellReuseIdentifier: "ClassListTableViewCell")
        }
    }
    
    var classList: [classlistdata] = [] // Corrected to use classlistdata struct

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true
        fetchClassList()
    }
    
    @IBAction func profileBt(_ sender: Any) {
        let profileVC = storyboard?.instantiateViewController(withIdentifier: "studentProfileViewController") as! studentProfileViewController
        navigationController?.pushViewController(profileVC, animated: true)
    }
    
    @IBAction func createBt(_ sender: Any) {
        let createClassVC = storyboard?.instantiateViewController(withIdentifier: "CreateclassViewController") as! CreateclassViewController
        navigationController?.pushViewController(createClassVC, animated: true)
    }
    
    func fetchClassList() {
        guard let id = Constants.loginResponse?.data.first?.id else {
            print("Error: id not found")
            return
        }
        
        APIHandler.shared.postAPIValues(type: Classlist.self,apiUrl: ApiList.class_list,method: "POST",formData: ["id":id] ) { result in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    if response.status {
                        self.classList = response.data
                        self.listTableview.reloadData()
                    } else {
                        print(" No classes found: \(response.message)")
                        Utils.showAlert(on: self, title: "Error", message: response.message)
                    }
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    print(" Error fetching class list: \(error.localizedDescription)")
                    Utils.showAlert(on: self, title: "Error", message: "Failed to fetch class list")
                }
            }
        }
    }
}

extension TeacherHomeViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return classList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ClassListTableViewCell", for: indexPath) as! ClassListTableViewCell
        let classData = classList[indexPath.row]
        
        cell.classLabel.text = classData.className
        cell.classLabel.isHidden = false
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let studentHomeVC = storyboard?.instantiateViewController(withIdentifier: "AssignmentViewController") as! AssignmentViewController
        navigationController?.pushViewController(studentHomeVC, animated: true)
    }
}
