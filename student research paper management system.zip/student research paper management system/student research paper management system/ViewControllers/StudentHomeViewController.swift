import UIKit

class StudentHomeViewController: UIViewController {
    
    @IBOutlet weak var join: UIButton!
    @IBOutlet weak var profile: UIButton!
    @IBOutlet weak var listTableview: UITableView! {
        didSet {
            listTableview.delegate = self
            listTableview.dataSource = self
            listTableview.register(UINib(nibName: "ClassListTableViewCell", bundle: nil), forCellReuseIdentifier: "ClassListTableViewCell")
        }
    }

    var classList: [classes] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.hidesBackButton = true 
        fetchClassList()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false // Disables swipe-to-go-back
    }

    @IBAction func profileButtonTapped(_ sender: Any) {
        let profileVC = self.storyboard?.instantiateViewController(withIdentifier: "studentProfileViewController") as! studentProfileViewController
        self.navigationController?.pushViewController(profileVC, animated: true)
    }

    @IBAction func joinButtonTapped(_ sender: Any) {
        let joinVC = self.storyboard?.instantiateViewController(withIdentifier: "CodeViewController") as! CodeViewController
        self.navigationController?.pushViewController(joinVC, animated: true)
    }

    func fetchClassList() {
        guard let id = Constants.loginResponse?.data.first?.id else {
            print("Error: id not found")
            return
        }
        APIHandler.shared.postAPIValues(
            type: EnrolledclassesModel.self,
            apiUrl: ApiList.listEnrollUrl,
            method: "POST",
            formData: ["id": id]
        ) { result in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    if response.status {
                        self.classList = response.data
                        self.listTableview.reloadData()
                    } else {
                        print(" No classes found: \(response.message)")
                        Utils.showAlert(on: self, title: "Error", message: response.message)
                    }
                }
            case .failure(let error):
                DispatchQueue.main.async {
                    print(" Error fetching class list: \(error.localizedDescription)")
                    Utils.showAlert(on: self, title: "Error", message: "Failed to fetch class list")
                }
            }
        }
    }
}

extension StudentHomeViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return classList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ClassListTableViewCell", for: indexPath) as! ClassListTableViewCell
        let classData = classList[indexPath.row]
        cell.classLabel.text = classData.className
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedClass = classList[indexPath.row]
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "MarksViewController") as! MarksViewController
        vc.classroomID = selectedClass.classroomID
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
