import UIKit

class StudentlistViewController: UIViewController,StudentAssignmentCellDelegate {
   
    
    
    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var listTableview: UITableView! {
        didSet {
            listTableview.delegate = self
            listTableview.dataSource = self
            listTableview.register(UINib(nibName: "StudentAssignmentTableViewCell", bundle: nil), forCellReuseIdentifier: "StudentAssignmentTableViewCell")
        }
    }
    var enrollementData: [EnrollementListData] = []
    var submitedListData: [SubmitListData] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        postApi()
    }

    @IBAction func segmentedControlChanged(_ sender: UISegmentedControl) {
        postApi()
    }
    
    func didTapSubmitButton(for cell: StudentAssignmentTableViewCell) {
        let vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "uploadViewController") as! uploadViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension StudentlistViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return segmentedControl.selectedSegmentIndex == 0 ? enrollementData.count : submitedListData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StudentAssignmentTableViewCell", for: indexPath) as! StudentAssignmentTableViewCell
        cell.delegate = self
        if segmentedControl.selectedSegmentIndex == 0 {
            cell.assignmentLabel.text = "\(indexPath.row + 1). " + enrollementData[indexPath.row].name
            cell.marksLabel.isHidden = true
            cell.submitButton.isHidden = true
        } else {
            cell.assignmentLabel.text = "\(indexPath.row + 1). " + submitedListData[indexPath.row].name
            cell.marksLabel.text = "\(submitedListData[indexPath.row].marks ?? 0)"
            cell.marksLabel.isHidden = false
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
}

extension StudentlistViewController {
    func postApi() {
        if segmentedControl.selectedSegmentIndex == 0 {
            let param = ["classroom_id": 3]
            
            APIHandler.shared.postAPIValues(type: EnrollementListModel.self, apiUrl: ApiList.listEnrollUrl, method: "POST", formData: param) { result in
                switch result {
                case .success(let response):
                    DispatchQueue.main.async {
                        if response.status {
                            self.enrollementData = response.data
                            self.listTableview.reloadData()
                        }
                    }
                case .failure(let err):
                    print(err)
                    Utils.showAlert(on: self, title: "", message: "Error fetching enrollment data")
                }
            }
        } else {
            let param = ["assignment_id": 2]
            
            APIHandler.shared.postAPIValues(type: SubmitListModel.self, apiUrl: ApiList.listSubmitUrl, method: "POST", formData: param) { result in
                switch result {
                case .success(let response):
                    DispatchQueue.main.async {
                        if response.status {
                            self.submitedListData = response.data
                            self.listTableview.reloadData()
                        }
                    }
                case .failure(let err):
                    print(err)
                    Utils.showAlert(on: self, title: "", message: "Error fetching submitted assignments")
                }
            }
        }
    }
}
