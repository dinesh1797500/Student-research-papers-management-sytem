import UIKit

class MarksViewController: UIViewController, StudentAssignmentCellDelegate {
    
    var classroomID: Int?
    var assignments: [Assignment] = []
    
    @IBOutlet weak var listTableview: UITableView! {
        didSet {
            listTableview.delegate = self
            listTableview.dataSource = self
            listTableview.register(UINib(nibName: "StudentAssignmentTableViewCell", bundle: nil), forCellReuseIdentifier: "StudentAssignmentTableViewCell")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let id = classroomID {
            print("Loaded MarksViewController for classroom ID: \(id)")
        } else {
            print("No classroom ID provided")
        }
        
        fetchAssignments()
    }
    
    func fetchAssignments() {
        guard let id = classroomID else {
            print("Error: classroomID is nil")
            return
        }
        
        guard let studentID = Constants.loginResponse?.data.first?.id else {
            print("Error: student ID is nil")
            return
        }
        
        // Construct the URL with proper parameter encoding
        let urlString = "\(ApiList.studentMarksURL)?id=\(studentID)&classroom_id=\(id)"
        guard let url = URL(string: urlString) else {
            print("Error: Invalid URL - \(urlString)")
            return
        }
        print("Fetching from URL: \(url.absoluteString)")
        
        APIHandler.shared.getAPIValues(
            type: AssignmentModel.self,
            apiUrl: url.absoluteString,
            method: "GET"
        ) { result in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    print("API Response: \(response)")
                    if response.status {
                        print("Assignments fetched successfully")
                        self.assignments = response.data
                        
                        if self.assignments.isEmpty {
                            print("No assignments found for this classroom.")
                        }
                        self.listTableview.reloadData()
                    } else {
                        print("No assignments found: \(response.message)")
                        Utils.showAlert(on: self, title: "Error", message: response.message)
                    }
                }
            case .failure(let error):
                print("API Request Failed: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    Utils.showAlert(on: self, title: "Error", message: "Failed to fetch assignments. Error: \(error.localizedDescription)")
                }
            }
        }
    }
    
    func didTapSubmitButton(for cell: StudentAssignmentTableViewCell) {
        guard let indexPath = listTableview.indexPath(for: cell) else { return }
        let selectedAssignment = assignments[indexPath.row]
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "ViewAssignmentViewController") as! ViewAssignmentViewController
        vc.idData = selectedAssignment.assignmentID
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension MarksViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return assignments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StudentAssignmentTableViewCell", for: indexPath) as! StudentAssignmentTableViewCell
        let assignment = assignments[indexPath.row]
        
        cell.assignmentLabel.text = "Assignment ID: \(assignment.assignmentID)"
        cell.marksLabel.text = "Marks: \(assignment.marks)"
        cell.delegate = self
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selectedAssignment = assignments[indexPath.row]
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ViewAssignmentViewController") as! ViewAssignmentViewController
        vc.idData = selectedAssignment.assignmentID
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
