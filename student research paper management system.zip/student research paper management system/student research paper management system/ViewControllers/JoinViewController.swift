import UIKit

class JoinViewController: UIViewController {

    @IBOutlet weak var join: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        

        
    }
    

    @IBAction func jo(_ sender: Any) {
        let joinVC = (self.storyboard?.instantiateViewController(withIdentifier: "CreateViewController") as? CreateViewController)!
        self.navigationController?.pushViewController(joinVC, animated: true)

    }
}
   


