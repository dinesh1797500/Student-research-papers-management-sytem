import UIKit

class forgotViewController: UIViewController {
    @IBOutlet weak var emailTextfeild: UITextField!
    @IBOutlet weak var newpasswordTextfeild: UITextField!
    @IBOutlet weak var confirmpasswordTextfeild: UITextField!
    @IBOutlet weak var submitBt: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func submitBt(_ sender: Any) {
        guard let email = emailTextfeild.text, !email.isEmpty,
              let newPassword = newpasswordTextfeild.text, !newPassword.isEmpty,
              let confirmPassword = confirmpasswordTextfeild.text, !confirmPassword.isEmpty else {
            Utils.showAlert(on: self, title: "Error", message: "All fields are required.")
            return
        }
        
        if newPassword != confirmPassword {
            Utils.showAlert(on: self, title: "Error", message: "Passwords do not match.")
            return
        }
        
        // Call the API to reset password
        PostApi(email: email, newpassword: newPassword, confirmPassword: confirmPassword)
    }
}

extension forgotViewController {
    func PostApi(email: String, newpassword: String, confirmPassword: String) {
        let param = ["email": email, "new_password": newpassword, "confirm_password": confirmPassword]

        APIHandler.shared.postAPIValues(
            type: ForgotPasswordModel.self, apiUrl: ApiList.forgot_password, method: "POST", formData: param
        ) { result in
            DispatchQueue.main.async {
                switch result {
                case .success(let response):
                    if response.status.lowercased() == "true" {  // ✅ Convert status to lowercase and compare as a string
                        let alert = UIAlertController(title: "Success", message: "Password reset successfully.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                            self.navigateToLogin() // ✅ Navigate after pressing OK
                        })
                        self.present(alert, animated: true, completion: nil)
                    } else {
                        Utils.showAlert(on: self, title: "Error", message: response.message)
                    }
                case .failure(let error):
                    print("API Error: \(error)")
                    Utils.showAlert(on: self, title: "Error", message: "Failed to reset password. Please try again.")
                }
            }
        }
    

    func navigateToLogin() {
        if let loginVC = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
            self.navigationController?.pushViewController(loginVC, animated: true)
        }
    }
}


    func navigateToLogin() {
        if let loginVC = storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController {
            self.navigationController?.pushViewController(loginVC, animated: true)
        }
    }
}
