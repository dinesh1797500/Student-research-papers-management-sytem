import UIKit

class AssignmentViewController: UIViewController {
    
    @IBOutlet weak var create: UIButton!
    @IBOutlet weak var listTableview: UITableView! {
        didSet {
            listTableview.delegate = self
            listTableview.dataSource = self
            print("TableView initialized with delegate and dataSource")
        }
    }
    
    var classroomID: String? {
        didSet {
            print("classroomID didSet triggered. Old value: \(oldValue ?? "nil"), New value: \(classroomID ?? "nil")")
            if classroomID != nil {
                print("ClassroomID set to: \(classroomID!) - Fetching assignments")
                fetchAssignments()
            } else {
                print("ClassroomID is nil - Skipping fetch")
            }
        }
    }
    var assignments: [String] = []
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        print("AssignmentViewController initialized via init(nibName:bundle:)")
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        print("AssignmentViewController initialized via storyboard")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("ViewDidLoad called")
        print("ClassroomID at viewDidLoad: \(classroomID ?? "nil")")
        print("TableView delegate: \(String(describing: listTableview.delegate))")
        print("TableView dataSource: \(String(describing: listTableview.dataSource))")
        
        if classroomID != nil {
            print("ClassroomID available in viewDidLoad - Fetching assignments")
            fetchAssignments()
        } else {
            print("ClassroomID is nil in viewDidLoad - Waiting for it to be set")
        }
    }
    
    @IBAction func create(_ sender: Any) {
        guard let joinVC = storyboard?.instantiateViewController(withIdentifier: "SubmitassignmentViewController") as? SubmitassignmentViewController else {
            print("Error: Could not instantiate SubmitassignmentViewController")
            return
        }
        navigationController?.pushViewController(joinVC, animated: true)
    }
    
    func fetchAssignments() {
        guard let classroomID = classroomID else {
            print("Error: Classroom ID is nil in fetchAssignments")
            return
        }
        
        guard let url = URL(string: APIConstants.assignmentListURL) else {
            print("Error: Invalid URL: \(APIConstants.assignmentListURL)")
            return
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let postString = "classroom_id=\(classroomID)"
        request.httpBody = postString.data(using: .utf8)
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        
        print("Fetching assignments for classroomID: \(classroomID)")
        print("Request URL: \(url.absoluteString)")
        print("Request Body: \(postString)")
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let httpResponse = response as? HTTPURLResponse {
                print("HTTP Status Code: \(httpResponse.statusCode)")
                print("Response Headers: \(httpResponse.allHeaderFields)")
            }
            
            if let error = error {
                print("Network Error: \(error.localizedDescription)")
                return
            }
            
            guard let data = data else {
                print("Error: No data received from API")
                return
            }
            
            do {
                if let jsonString = String(data: data, encoding: .utf8) {
                    print("Raw API Response: \(jsonString)")
                }
                
                let decodedResponse = try JSONDecoder().decode(AssignmentListModel.self, from: data)
                DispatchQueue.main.async {
                    if decodedResponse.status {
                        print("Fetched \(decodedResponse.data.count) assignments")
                        self.assignments = decodedResponse.data
                        self.listTableview.reloadData()
                        print("TableView updated with \(self.assignments.count) items")
                    } else {
                        print("API Error Message: \(decodedResponse.message)")
                    }
                }
            } catch {
                print("Decoding Error: \(error)")
                if let jsonString = String(data: data, encoding: .utf8) {
                    print("Failed Response: \(jsonString)")
                }
            }
        }
        task.resume()
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension AssignmentViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("Number of rows requested: \(assignments.count)")
        return assignments.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "AssignmentTableViewCell",
                                                      for: indexPath) as? AssignmentTableViewCell else {
            print("Error: Could not dequeue AssignmentTableViewCell")
            return UITableViewCell()
        }
        cell.configure(with: assignments[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        guard let vc = storyboard?.instantiateViewController(withIdentifier: "AssignmentViewController") as? AssignmentViewController else {
            print("Error: Could not instantiate AssignmentViewController")
            return
        }
        navigationController?.pushViewController(vc, animated: true)
    }
}
