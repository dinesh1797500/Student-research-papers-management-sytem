//
//  CreateViewController.swift
//  student research paper management system
//
//  Created by SAIL on 17/02/25.
//

import UIKit

class CreateViewController: UIViewController {

    @IBOutlet weak var createBt: UIButton!
    @IBOutlet weak var loginBt: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    @IBAction func jo(_ sender: Any) {
        let loginBt = (self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as? LoginViewController)!
        self.navigationController?.pushViewController(loginBt, animated: true)
    }
    
    @IBAction func createBtn(_ sender: Any) {
        let creatBt = (self.storyboard?.instantiateViewController(withIdentifier: "SignUpViewController") as? SignUpViewController)!
        self.navigationController?.pushViewController(creatBt, animated: true)
    }
    

}
