import UIKit
import UniformTypeIdentifiers

class uploadViewController: UIViewController, UIDocumentPickerDelegate {
    
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var uploadButton: UIButton!
    
    // MARK: - Actions
    @IBAction func submit(_ sender: Any) {
        let submitVC = storyboard?.instantiateViewController(withIdentifier: "MarksViewController") as! MarksViewController
        navigationController?.pushViewController(submitVC, animated: true)
    }
    
    @IBAction func upload(_ sender: Any) {
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [UTType.pdf])
        documentPicker.delegate = self
        documentPicker.allowsMultipleSelection = false
        present(documentPicker, animated: true)
    }
    
    // MARK: - UIDocumentPickerDelegate
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let selectedFileURL = urls.first else {
            print("No file selected.")
            return
        }
        print("Selected PDF URL: \(selectedFileURL)")
    }
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("User cancelled document picker")
    }
}
