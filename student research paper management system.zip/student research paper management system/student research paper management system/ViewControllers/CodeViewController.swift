import UIKit

class CodeViewController: UIViewController {

    @IBOutlet weak var code: UITextField!
    @IBOutlet weak var join: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func joinBt(_ sender: Any) {
        guard let codeText = code.text, !codeText.isEmpty else {
            showAlert(title: "Error", message: "Please enter a classroom code")
            return
        }

        //  Fetch student ID from stored login response
        guard let studentID = Constants.loginResponse?.data.first?.id else {
            showAlert(title: "Error", message: "User ID not found")
            return
        }

        let urlString = ApiList.codeURL
        guard let url = URL(string: urlString) else {
            showAlert(title: "Error", message: "Invalid URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        //  Include both `id` (student ID) and `class_code` in the request body
        let bodyData = "id=\(studentID)&class_code=\(codeText)"
        request.httpBody = bodyData.data(using: .utf8)

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showAlert(title: "Network Error", message: error.localizedDescription)
                }
                return
            }

            guard let data = data else {
                DispatchQueue.main.async {
                    self.showAlert(title: "Error", message: "No data received from the server")
                }
                return
            }

            do {
                if let jsonResponse = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                    DispatchQueue.main.async {
                        if let status = jsonResponse["status"] as? Bool, status {
                            self.navigateToStudentHome()
                        } else {
                            let message = jsonResponse["message"] as? String ?? "Invalid classroom code"
                            self.showAlert(title: "Error", message: message)
                        }
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.showAlert(title: "Parsing Error", message: "Failed to parse server response")
                }
            }
        }
        task.resume()
    }

    // ✅ Navigate to Student Home
    func navigateToStudentHome() {
        if let joinVC = storyboard?.instantiateViewController(withIdentifier: "StudentHomeViewController") as? StudentHomeViewController {
            navigationController?.pushViewController(joinVC, animated: true)
        }
    }

    // ✅ Helper function to show alerts
    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        DispatchQueue.main.async {
            self.present(alert, animated: true)
        }
    }
}
