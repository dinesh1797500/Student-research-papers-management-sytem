import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var forgot: UIButton!
    @IBOutlet weak var login: UIButton!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func loginBt(_ sender: Any) {
        guard let emailText = email.text, let passwordText = password.text else {
            return
        }

        postApi(email: emailText, password: passwordText)
    }

    @IBAction func forgotBt(_ sender: Any) {
        let joinVC = (self.storyboard?.instantiateViewController(withIdentifier: "forgotViewController") as? forgotViewController)!
        self.navigationController?.pushViewController(joinVC, animated: true)
    }
}

extension LoginViewController {
    func postApi(email: String, password: String) {
        let param = ["email": email, "password": password]
        
        APIHandler.shared.postAPIValues(type: LoginModel.self, apiUrl: ApiList.loginUrl, method: "POST", formData: param) { result in
            switch result {
            case .success(let response):
                DispatchQueue.main.async {
                    if response.status {
                        Constants.loginResponse = response
                        if response.data.first?.role == "teacher" {
                            let teacherVC = (self.storyboard?.instantiateViewController(withIdentifier: "TeacherHomeViewController") as? TeacherHomeViewController)!
                            self.navigationController?.pushViewController(teacherVC, animated: true)
                        } else {
                            let studentVC = (self.storyboard?.instantiateViewController(withIdentifier: "StudentHomeViewController") as? StudentHomeViewController)!
                            self.navigationController?.pushViewController(studentVC, animated: true)
                        }
                    } else {
                        Utils.showAlert(on: self, title: "", message: response.message)
                    }
                }
            case .failure(let err):
                print(err)
                DispatchQueue.main.async {
                    Utils.showAlert(on: self, title: "", message: "Error fetching login data")
                }
            }
        }
    }
}
