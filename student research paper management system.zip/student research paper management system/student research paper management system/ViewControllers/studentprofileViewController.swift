import UIKit
class studentProfileViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var role: UITextField!
    @IBOutlet weak var phone: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var save: UIButton!
    @IBOutlet weak var logout: UIButton!
    @IBOutlet weak var changeProfile: UIButton!
    @IBOutlet weak var profileImageview: UIImageView!

    let profileURL = ApiList.profileURL
    let updateProfileURL = ApiList.updateProfileURL
    let profileImageURL = ApiList.profile_image

    override func viewDidLoad() {
        super.viewDidLoad()
        role.isUserInteractionEnabled = false
        role.backgroundColor = UIColor.lightGray.withAlphaComponent(0.5)
        getProfileApi()
        profileImageview.layer.cornerRadius = profileImageview.frame.width / 2
        profileImageview.clipsToBounds = true
    }
    func getProfileApi() {
       
        APIHandler.shared.getAPIValues(type: ViewProfileModel.self, apiUrl: ApiList.profileURL + "?id=\(Constants.loginResponse?.data.first?.id ?? 0)", method: "GET") { result in
                switch result {
                case .success(let response):
                    DispatchQueue.main.async {
                        if response.status {
                            let user = response.data
                                self.name.text = user.name
                                self.phone.text = user.phone
                                self.email.text = user.email
                                self.role.text = user.role
                            self.password.text = user.password
                            if let imageUrl = URL(string: ApiList.baseUrl + user.profileImage) {
                              self.loadProfileImage(from: imageUrl)
                              }
                            }
                    }
                case .failure(let err):
                    print(err)
                    Utils.showAlert(on: self, title: "", message: "Error fetching enrollment data")
                }
            }
    }

    // MARK: - Fetch User Details from API
    func loadUserDetails() {
//        guard let id = UserDefaults.standard.string(forKey: "id") else {
//            showAlert(title: "Error", message: "id not found. Please log in again.")
//            return
//        }
        let urlString = "\(profileURL)?id=1"
        guard let url = URL(string: urlString) else {
            print(" Invalid URL: \(urlString)")
            return
        }

        print(" Fetching Profile from URL: \(urlString)")

        var request = URLRequest(url: url)
        request.httpMethod = "GET"

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                DispatchQueue.main.async {
                    self.showAlert(title: "Error", message: "Network error: \(error.localizedDescription)")
                }
                print(" Network Error: \(error.localizedDescription)")
                return
            }
            guard let data = data else {
                print(" No data received from API")
                DispatchQueue.main.async {
                    self.showAlert(title: "Error", message: "No data received from server.")
                }
                return
            }
            let responseString = String(data: data, encoding: .utf8) ?? "No response data"
            print(" API Response: \(responseString)")
            
            do {
                let user = try JSONDecoder().decode(User.self, from: data)
                DispatchQueue.main.async {
                    self.name.text = user.name
                    self.phone.text = user.phone
                    self.email.text = user.email
                    self.role.text = user.role
                    
                    if let imageUrl = URL(string: user.profileImage) {
                        self.loadProfileImage(from: imageUrl)
                    }
                }
            } catch {
                DispatchQueue.main.async {
                    self.showAlert(title: "Error", message: "Failed to parse profile data.")
                }
                print("JSON Parsing Error: \(error)")
            }
        }
        task.resume()
    }
    
    // Load Profile Image
    func loadProfileImage(from url: URL) {
        DispatchQueue.global().async {
            if let data = try? Data(contentsOf: url), let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.profileImageview.image = image
                }
            } else {
                print(" Failed to load profile image from URL: \(url)")
            }
        }
    }

    // MARK: - Change Profile Picture
    @IBAction func changeProfileTapped(_ sender: Any) {
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        imagePicker.allowsEditing = true
        present(imagePicker, animated: true, completion: nil)
    }

    // Image Picker Delegate
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey: Any]) {
        if let selectedImage = info[.editedImage] as? UIImage {
            profileImageview.image = selectedImage
            uploadProfileImage(selectedImage)
        }
        dismiss(animated: true, completion: nil)
    }

    // MARK: - Upload Profile Picture to Server
    func uploadProfileImage(_ image: UIImage) {
        guard let imageData = image.jpegData(compressionQuality: 0.7) else { return }
        guard let url = URL(string: profileImageURL) else { return }
        
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        
        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")

        var body = Data()
        let fileName = "profile.jpg"
        let mimeType = "image/jpeg"
        
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"profile_image\"; filename=\"\(fileName)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: \(mimeType)\r\n\r\n".data(using: .utf8)!)
        body.append(imageData)
        body.append("\r\n".data(using: .utf8)!)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        
        request.httpBody = body
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    self.showAlert(title: "Error", message: "Failed to upload profile image: \(error.localizedDescription)")
                    return
                }
                self.showAlert(title: "Success", message: "Profile image updated successfully!")
            }
        }
        task.resume()
    }

    @IBAction func saveProfile(_ sender: Any) {
        guard let updatedName = name.text, !updatedName.isEmpty,
              let updatedPhone = phone.text, !updatedPhone.isEmpty,
              let updatedEmail = email.text, !updatedEmail.isEmpty else {
            showAlert(title: "Error", message: "All fields are required")
            return
        }

        guard let url = URL(string: updateProfileURL) else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let postString = "name=\(updatedName)&phone=\(updatedPhone)&email=\(updatedEmail)"
        request.httpBody = postString.data(using: .utf8)

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    self.showAlert(title: "Error", message: error.localizedDescription)
                    return
                }
                self.showAlert(title: "Success", message: "Profile updated successfully")
            }
        }
        task.resume()
    }
    @IBAction func logoutTapped(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "id")
        UserDefaults.standard.synchronize()
        
        let loginVC = self.storyboard?.instantiateViewController(withIdentifier: "CreateViewController") as! CreateViewController
        self.navigationController?.setViewControllers([loginVC], animated: true)
    }

    func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}

struct User: Codable {
    let name: String
    let phone: String
    let email: String
    let role: String
    let profileImage: String
}
