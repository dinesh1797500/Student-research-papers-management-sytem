//
//  Constants.swift
//  PDF TO MP3
//
//  Created by SAIL L1 on 08/02/25.
//

import Foundation

struct APIList {
    static let baseURL = "http://localhost/srm/"
    static let register = baseURL + "signup.php"
    
    
}

