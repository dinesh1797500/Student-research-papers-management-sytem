//
//  AssignmentTableViewCell.swift
//  student research paper management system
//
//  Created by SAIL on 08/02/25.
//

import UIKit

class AssignmentTableViewCell: UITableViewCell {
    @IBOutlet weak var nameLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        nameLabel.numberOfLines = 0
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    func configure(with assignment: String) {
        nameLabel.text = assignment
    }
}
