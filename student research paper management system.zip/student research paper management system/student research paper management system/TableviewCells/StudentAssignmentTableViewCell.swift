import UIKit

// Define a protocol for button action
protocol StudentAssignmentCellDelegate: AnyObject {
    func didTapSubmitButton(for cell: StudentAssignmentTableViewCell)
}

class StudentAssignmentTableViewCell: UITableViewCell {
    
    @IBOutlet weak var assignmentLabel: UILabel!
    @IBOutlet weak var marksLabel: UILabel!
    @IBOutlet weak var submitButton: UIButton!

    weak var delegate: StudentAssignmentCellDelegate? // Delegate reference

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    func configureCell(assignmentName: String, marks: String) {
        assignmentLabel.text = assignmentName
        marksLabel.text = marks
    }

    @IBAction func submitBt(_ sender: Any) {
        delegate?.didTapSubmitButton(for: self) // Notify delegate
    }
}

