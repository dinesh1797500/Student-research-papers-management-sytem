<?php
include 'db.php'; 
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $assignment_id = intval($_GET['id']);
    
    $query = "SELECT id, title, description, file FROM assignments WHERE id = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("i", $assignment_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            echo json_encode([
                "status" => true,
                "message" => "Assignment fetched successfully",
                "data" => [
                    "id" => (int)$row['id'],
                    "title" => $row['title'],
                    "description" => $row['description'],
                    "file" => $row['file'] // Relative path, e.g., "uploads/assignment1.pdf"
                ]
            ]);
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Assignment not found"
            ]);
        }
        
        $stmt->close();
    } else {
        echo json_encode([
            "status" => false,
            "message" => "SQL Error: " . $conn->error
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method or missing ID"
    ]);
}

$conn->close();
?>