<?php
include 'db.php'; 
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['classroom_id']) && isset($_GET['id'])) {
        $classroom_id = intval($_GET['classroom_id']);
        $id = intval($_GET['id']);

        $query = "SELECT a.id AS assignment_id, MAX(s.marks) AS marks
                  FROM assignments a
                  LEFT JOIN submissions s 
                  ON a.id = s.assignment_id AND s.id = ?
                  WHERE a.classroom_id = ?
                  GROUP BY a.id
                  ORDER BY a.due_date DESC";

        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param("ii", $id, $classroom_id);
            $stmt->execute();
            $result = $stmt->get_result();

            $assignments = [];
            while ($row = $result->fetch_assoc()) {
                $assignments[] = [
                    "assignment_id" => (string)$row['assignment_id'], // Cast to string to match Swift model
                    "marks" => $row['marks'] ?? 0 // If marks is NULL, set to 0
                ];
            }

            echo json_encode([
                "status" => true,
                "message" => count($assignments) > 0 ? "Assignments fetched successfully." : "No assignments found.",
                "data" => $assignments
            ]);

            $stmt->close();
        } else {
            echo json_encode([
                "status" => false,
                "message" => "SQL Error: " . $conn->error
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Missing classroom_id or id."
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method."
    ]);
}

$conn->close();
?>