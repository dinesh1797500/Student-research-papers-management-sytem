<?php
header('Content-Type: application/json');


include 'db.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $role= $_POST['role'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    


    if ($password !== $confirm_password) {
        echo json_encode([
            "status" => false,
            "message" => "Passwords do not match.",
            "data" => []
        ]);
        exit;
    }


    $sql_check = "SELECT * FROM users WHERE email = ?";
    $stmt_check = $conn->prepare($sql_check);
    $stmt_check->bind_param("s", $email);
    $stmt_check->execute();
    $result_check = $stmt_check->get_result();


    if ($result_check->num_rows > 0) {
        echo json_encode([
            "status" => false,
            "message" => "email already exists.",
            "data" => []
        ]);
        $stmt_check->close();
        exit;
    }


    $sql = "INSERT INTO users (name,role, phone, email, password) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssss", $name, $role, $phone, $email, $password);


    if ($stmt->execute()) {
        echo json_encode([
            "status" => true,
            "message" => "User registered successfully.",
            "data" => [
                [
                    "id" => $conn->insert_id,
                    "name" => $name,
                    "role" => $role,
                    "phone" => $phone,
                    "email" => $email,
                    "password"=> $password,
                    "confirm_password"=> $confirm_password

                ]
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Error: " . $stmt->error,
            "data" => []
        ]);
    }


    $stmt->close();
}
$conn->close();
?>
