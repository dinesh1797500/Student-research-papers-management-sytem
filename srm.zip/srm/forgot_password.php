<?php
include('db.php'); // Include database connection
header('Content-Type: application/json');

// Check if request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate required fields
    if (isset($_POST['email']) && isset($_POST['new_password']) && isset($_POST['confirm_password'])) {
        $email = $conn->real_escape_string($_POST['email']);
        $new_password = $conn->real_escape_string($_POST['new_password']);
        $confirm_password = $conn->real_escape_string($_POST['confirm_password']);

        // Check if new password matches confirm password
        if ($new_password !== $confirm_password) {
            echo json_encode([
                "Status" => "False",
                "Message" => "Passwords do not match.",
                "Data" => []
            ]);
            exit;
        }

        // Check if email exists
        $checkQuery = "SELECT id, name, email FROM users WHERE email = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows == 0) {
            echo json_encode([
                "Status" => "False",
                "Message" => "Email not found.",
                "Data" => []
            ]);
            $stmt->close();
            exit;
        }

        // Fetch user details
        $user = $result->fetch_assoc();
        $stmt->close();

        // Store password in plain text (⚠️ VERY INSECURE)
        $updateQuery = "UPDATE users SET password = ? WHERE email = ?";
        $stmt = $conn->prepare($updateQuery);
        $stmt->bind_param("ss", $new_password, $email);

        if ($stmt->execute()) {
            echo json_encode([
                "Status" => "True",
                "Message" => "Password reset successfully.",
                "Data" => [
                    "id" => $user['id'],
                    "name" => $user['name'],
                    "email" => $user['email'],
                    "updated_password" => $new_password // ⚠️ Plain-text password returned
                ]
            ]);
        } else {
            echo json_encode([
                "Status" => "False",
                "Message" => "Error updating password.",
                "Data" => []
            ]);
        }
        $stmt->close();
    } else {
        echo json_encode([
            "Status" => "False",
            "Message" => "Invalid input or missing required fields.",
            "Data" => []
        ]);
    }
} else {
    echo json_encode([
        "Status" => "False",
        "Message" => "Invalid request method.",
        "Data" => []
    ]);
}
?>
