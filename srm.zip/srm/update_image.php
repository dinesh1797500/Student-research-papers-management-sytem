<?php
include 'db.php'; // Database connection file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $target_dir = "uploads/";
    $imageName = time() . "_" . basename($_FILES["image"]["name"]);
    $target_file = $target_dir . $imageName;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Validate image type
    $allowed_types = array("jpg", "jpeg", "png");
    if (!in_array($imageFileType, $allowed_types)) {
        echo json_encode(["status" => "error", "message" => "Invalid file type"]);
        exit();
    }

    if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
        $imageURL = "https://yourserver.com/uploads/" . $imageName;
        
        // Save image URL to database (modify as needed)
        $stmt = $conn->prepare("UPDATE users SET profile_image=? WHERE email=?");
        $stmt->bind_param("ss", $imageURL, $_POST["email"]);
        $stmt->execute();
        
        echo json_encode(["status" => "success", "image_url" => $imageURL]);
    } else {
        echo json_encode(["status" => "error", "message" => "Image upload failed"]);
    }
}
?>
