<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php'; 

header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => false, "message" => "Invalid request method. Use POST.", "data" => []]);
    exit;
}
if (!isset($_POST['classroom_id']) || empty($_POST['classroom_id'])) {
    echo json_encode(["status" => false, "message" => "Missing required field: classroom_id", "data" => []]);
    exit;
}
$classroom_id = intval($_POST['classroom_id']);
$query = "SELECT title FROM Assignments WHERE classroom_id = ? ORDER BY id DESC";

$stmt = $conn->prepare($query);
if (!$stmt) {
    echo json_encode(["status" => false, "message" => "Database query preparation failed: " . $conn->error, "data" => []]);
    exit;
}

$stmt->bind_param("i", $classroom_id);
$stmt->execute();
$result = $stmt->get_result();

$assignments = [];

// Fetch results
while ($row = $result->fetch_assoc()) {
    $assignments[] = $row['title']; // Store only assignment names
}

// Close connection
$stmt->close();
$conn->close();

// Return JSON response
echo json_encode([
    "status" => true,
    "message" => "Assignments retrieved successfully.",
    "data" => $assignments
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>