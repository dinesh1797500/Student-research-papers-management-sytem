<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php'; // Include database connection

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => false, "message" => "Invalid request method. Use POST."]);
    exit;
}

// Debugging: Log POST and FILES data
error_log("POST Data: " . print_r($_POST, true));
error_log("FILES Data: " . print_r($_FILES, true));

// Check required fields
if (
    empty($_POST['assignment_id']) ||  // ✅ Expect assignment_id from the request
    empty($_POST['classroom_id']) ||
    empty($_POST['id']) ||
    empty($_POST['title']) ||
    empty($_POST['description']) ||
    empty($_POST['due_date']) ||
    !isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK
) {
    echo json_encode(["status" => false, "message" => "Missing required fields or file upload failed."]);
    exit;
}

// Get input data
$assignment_id = trim($_POST['assignment_id']);  // ✅ Use assignment_id from request
$classroom_id = intval($_POST['classroom_id']);
$id = intval($_POST['id']);
$title = trim($_POST['title']);
$description = trim($_POST['description']);
$due_date = $_POST['due_date'];

// ✅ Step 1: Check if classroom_id exists in Classrooms table
$checkQuery = "SELECT s_no FROM Classrooms WHERE s_no = ?";
$checkStmt = $conn->prepare($checkQuery);
$checkStmt->bind_param("i", $classroom_id);
$checkStmt->execute();
$result = $checkStmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(["status" => false, "message" => "Classroom ID does not exist. Check your classroom_id."]);
    exit;
}
$checkStmt->close();

// ✅ Step 2: Validate file type (Only PDF)
$allowed_extensions = ['pdf'];
$file_name = $_FILES["file"]["name"];
$file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

if (!in_array($file_extension, $allowed_extensions)) {
    echo json_encode(["status" => false, "message" => "Invalid file type. Only PDF allowed."]);
    exit;
}

// ✅ Step 3: Validate file size (Max: 10MB)
if ($_FILES["file"]["size"] > 10 * 1024 * 1024) { 
    echo json_encode(["status" => false, "message" => "File size exceeds 10MB limit."]);
    exit;
}

// ✅ Step 4: Create uploads directory if not exists
$directory = 'uploads/' . $classroom_id;
if (!is_dir($directory) && !mkdir($directory, 0777, true)) {
    echo json_encode(["status" => false, "message" => "Failed to create directory. Check permissions."]);
    exit;
}

// ✅ Step 5: Generate Unique File Path
$file_path = $directory . '/' . $assignment_id . '.' . $file_extension;

// ✅ Step 6: Move the uploaded file
if (!move_uploaded_file($_FILES['file']['tmp_name'], $file_path)) {
    echo json_encode(["status" => false, "message" => "Failed to save the file. Ensure folder has proper write permissions."]);
    exit;
}

// ✅ Step 7: Insert assignment into database
$insertQuery = "INSERT INTO Assignments (assignment_id, classroom_id, id, title, description, file, due_date) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($insertQuery);
$stmt->bind_param("siissss", $assignment_id, $classroom_id, $id, $title, $description, $file_path, $due_date);

if ($stmt->execute()) {
    echo json_encode([
        "status" => true,
        "message" => "Assignment uploaded successfully.",
        "assignment_id" => $assignment_id // ✅ Only return assignment_id
    ]);
} else {
    echo json_encode(["status" => false, "message" => "Database error: Could not upload assignment."]);
}

// Close database connection
$stmt->close();
$conn->close();
?>
