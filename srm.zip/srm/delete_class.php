<?php
include 'db.php'; 
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['class_id'])) {
        $class_id = intval($_POST['class_id']);

        $checkQuery = "SELECT * FROM Classrooms WHERE id = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("i", $class_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $deleteQuery = "DELETE FROM Classrooms WHERE id = ?";
            $stmt = $conn->prepare($deleteQuery);
            $stmt->bind_param("i", $class_id);

            if ($stmt->execute()) {
                echo json_encode([
                    "status" => true,
                    "message" => "Class deleted successfully.",
                    "data" => []
                ]);
            } else {
                echo json_encode([
                    "status" => false,
                    "message" => "Failed to delete class.",
                    "data" => []
                ]);
            }
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Class not found.",
                "data" => []
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Missing class ID.",
            "data" => []
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method.",
        "data" => []
    ]);
}
?>
