<?php
include 'db.php';
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo json_encode(["error" => "Invalid request method"]);
    exit;
}

// Get POST data
$teacher_id = intval($_POST['id']);
$classroom_id = intval($_POST['classroom_id']);  
$class_name = trim($_POST['class_name']);
$class_code = strtoupper(trim($_POST['class_code']));

// Check if required fields are provided
if (empty($teacher_id) || empty($classroom_id) || empty($class_name) || empty($class_code)) {
    echo json_encode(["error" => "All fields are required"]);
    exit;
}

// Check if classroom_id or class_code already exists
$check_query = "SELECT s_no FROM Classrooms WHERE classroom_id = ? OR class_code = ?";
$stmt = $conn->prepare($check_query);
$stmt->bind_param("is", $classroom_id, $class_code);
$stmt->execute();
$stmt->store_result();

if ($stmt->num_rows > 0) {
    $stmt->close();
    echo json_encode(["error" => "Classroom ID or Class Code already exists. Choose a different one."]);
    exit;
}
$stmt->close();

// Insert classroom
$query = "INSERT INTO Classrooms (id, classroom_id, class_name, class_code) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("iiss", $teacher_id, $classroom_id, $class_name, $class_code);

if ($stmt->execute()) {
    echo json_encode([
        "status" => true,
        "message" => "Class created successfully",
        "data" => [
            "classroom_id" => $classroom_id,
            "class_name" => $class_name,
            "class_code" => $class_code
        ]
    ]);
} else {
    echo json_encode([
        "status" => false,
        "message" => "Failed to create classroom",
        "data" => []
    ]);
}
$stmt->close();
$conn->close();

?>
