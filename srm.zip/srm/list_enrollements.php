<?php
include 'db.php';  // Database connection file

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {  // Ensure it's a POST request
    if (!isset($_POST['classroom_id'])) {
        echo json_encode(["status" => false, "message" => "Missing classroom_id.", "data" => []]);
        exit;
    }

    $classroom_id = intval($_POST['classroom_id']);  // Convert input to integer

    
    $classCheckQuery = "SELECT id FROM Classrooms WHERE id = ?";
    $stmt = $conn->prepare($classCheckQuery);
    $stmt->bind_param("i", $classroom_id);
    $stmt->execute();
    $classResult = $stmt->get_result();

    if ($classResult->num_rows === 0) {
        echo json_encode(["status" => false, "message" => "Classroom does not exist.", "data" => []]);
        exit;
    }
    $stmt->close();
    $query = "SELECT Users.id, Users.name, Users.email, Users.phone 
              FROM Users
              INNER JOIN Enrollments ON Users.id = Enrollments.id
              WHERE Enrollments.classroom_id = ? AND Users.role = 'student'";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $classroom_id);
    $stmt->execute();
    $result = $stmt->get_result();

    $students = [];
    while ($row = $result->fetch_assoc()) {
        $students[] = $row;
    }

    if (count($students) > 0) {
        echo json_encode(["status" => true, "message" => "Students fetched successfully.", "data" => $students]);
    } else {
        echo json_encode(["status" => false, "message" => "No students found for this classroom.", "data" => []]);
    }

    $stmt->close();
} else {
    echo json_encode(["status" => false, "message" => "Invalid request method. Use POST.", "data" => []]);
}
?>
