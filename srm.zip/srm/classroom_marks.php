<?php
// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php';

header('Content-Type: application/json');

// Ensure only GET requests are allowed
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["status" => false, "message" => "Invalid request method. Use GET."]);
    exit;
}

// Validate required parameters
if (
    !isset($_GET['classroom_id']) || !filter_var($_GET['classroom_id'], FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]]) ||
    !isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]])
) {
    http_response_code(400); // Bad Request
    echo json_encode([
        "status" => false,
        "message" => "Invalid or missing 'classroom_id' or 'id' parameter.",
        "debug" => ["received_get" => $_GET]
    ]);
    exit;
}

$classroom_id = intval($_GET['classroom_id']);
$id = intval($_GET['id']); // Logged-in student's ID

// Fetch assignments specific to the logged-in user (id)
$query = "
    SELECT 
        a.id AS assignment_id,
        COALESCE(s.marks, '') AS marks
    FROM Assignments a
    LEFT JOIN Submissions s ON a.id = s.assignment_id AND s.id = ?
    WHERE a.classroom_id = ?
    ORDER BY a.id ASC
";

$stmt = $conn->prepare($query);

if (!$stmt) {
    http_response_code(500); // Internal Server Error
    echo json_encode(["status" => false, "message" => "Database error. Please try again later."]);
    exit;
}

$stmt->bind_param("ii", $id, $classroom_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if records exist
if ($result->num_rows > 0) {
    $assignments = [];
    while ($row = $result->fetch_assoc()) {
        $assignments[] = [
            "assignment_id" => $row['assignment_id'],
            "marks" => $row['marks']
        ];
    }

    echo json_encode([
        "status" => true,
        "message" => "Assignments retrieved successfully.",
        "data" => $assignments
    ]);
} else {
    http_response_code(404); // Not Found
    echo json_encode([
        "status" => false,
        "message" => "No assignments found for the logged-in student.",
        "debug" => ["classroom_id" => $classroom_id, "id" => $id]
    ]);
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
