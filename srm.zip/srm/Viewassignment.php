<?php
// Enable error reporting for debugging (disable in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php';

header('Content-Type: application/json');

// Ensure only GET requests are allowed
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(["status" => false, "message" => "Invalid request method. Use GET."]);
    exit;
}

// Validate 'id' parameter (assignment_id)
if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT, ["options" => ["min_range" => 1]])) {
    http_response_code(400); // Bad Request
    echo json_encode([
        "status" => false,
        "message" => "Invalid or missing 'id' parameter.",
        "debug" => ["received_get" => $_GET]
    ]);
    exit;
}

$assignment_id = intval($_GET['id']);

// Fetch assignment marks for the given assignment_id
$query = "SELECT assignment_id, marks FROM Submissions WHERE assignment_id = ?";
$stmt = $conn->prepare($query);

if (!$stmt) {
    http_response_code(500); // Internal Server Error
    echo json_encode(["status" => false, "message" => "Database error. Please try again later."]);
    exit;
}

$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if records exist
if ($result->num_rows > 0) {
    $submissions = [];
    while ($row = $result->fetch_assoc()) {
        $submissions[] = [
            "assignment_id" => $row['assignment_id'],
            "marks" => $row['marks']
        ];
    }

    echo json_encode([
        "status" => true,
        "message" => "Submissions retrieved successfully.",
        "data" => $submissions
    ]);
} else {
    http_response_code(404); // Not Found
    echo json_encode([
        "status" => false,
        "message" => "No submissions found for the given assignment ID.",
        "debug" => ["assignment_id" => $assignment_id]
    ]);
}

// Close statement and connection
$stmt->close();
$conn->close();
?>
