<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php'; // Include database connection

header('Content-Type: application/json');

// Check for POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => false, "message" => "Invalid request method. Use POST."]);
    exit;
}

// Check if required fields are provided
if (empty($_POST['submission_id']) || !isset($_POST['marks'])) {
    echo json_encode(["status" => false, "message" => "Missing required fields: submission_id and marks."]);
    exit;
}

// Get input values
$submission_id = intval($_POST['submission_id']);
$marks = intval($_POST['marks']);

// Validate marks (optional)
if ($marks < 0 || $marks > 100) {  // Assuming marks range is 0-100
    echo json_encode(["status" => false, "message" => "Marks should be between 0 and 100."]);
    exit;
}

// Update marks in Submissions table
$query = "UPDATE Submissions SET marks = ? WHERE id = ?";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    echo json_encode(["status" => false, "message" => "Database query preparation failed: " . $conn->error]);
    exit;
}

$stmt->bind_param("ii", $marks, $submission_id);
$stmt->execute();

// Check if the update was successful
if ($stmt->affected_rows > 0) {
    echo json_encode(["status" => true, "message" => "Marks updated successfully."]);
} else {
    echo json_encode(["status" => false, "message" => "Failed to update marks. Submission not found or marks unchanged."]);
}

// Close connection
$stmt->close();
$conn->close();
?>
