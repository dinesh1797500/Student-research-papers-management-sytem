<?php
header('Content-Type: application/json');

// Include the database connection file
include 'db.php';

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id'];  
    if (empty($id)) {
        echo json_encode([
            "status" => false,
            "message" => "id is required.",
            "data" => []
        ]);
        exit;
    }

    // Fetch classes created by the teacher, including classroom_id
    $query = "SELECT s_no, id, classroom_id, class_name, class_code FROM Classrooms WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    $classes = [];

    // Fetch the results and store them in an array
    while ($row = $result->fetch_assoc()) {
        $classes[] = $row;
    }

    // Check if there are any classes for the teacher
    if (count($classes) > 0) {
        echo json_encode([
            "status" => true,
            "message" => "Classes retrieved successfully.",
            "data" => $classes
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "No classes found for this teacher.",
            "data" => []
        ]);
    }

    $stmt->close();
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method.",
        "data" => []
    ]);
}

$conn->close();
?>
