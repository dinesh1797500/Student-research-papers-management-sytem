<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php'; // Include database connection

header('Content-Type: application/json');

// Ensure request method is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => false, "message" => "Invalid request method. Use POST."]);
    exit;
}

// Debugging: Log raw POST and FILES data
error_log("RAW POST Data: " . file_get_contents("php://input"));
error_log("POST Data: " . print_r($_POST, true));
error_log("FILES Data: " . print_r($_FILES, true));

// Check required fields
if (
    empty($_POST['assignment_id']) ||
    empty($_POST['id']) ||
    !isset($_FILES['file'])
) {
    echo json_encode([
        "status" => false,
        "message" => "Missing required fields: assignment_id, id, or file.",
        "debug_post" => $_POST,
        "debug_files" => $_FILES
    ]);
    exit;
}

// Get input data
$assignment_id = intval($_POST['assignment_id']);
$id = intval($_POST['id']);

// Fetch classroom_id from the assignments table if not provided
$classroom_id = null;
if (!empty($_POST['classroom_id'])) {
    $classroom_id = intval($_POST['classroom_id']);
} else {
    $query = "SELECT classroom_id FROM assignments WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $assignment_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $classroom_id = $row['classroom_id'];
    }
    $stmt->close();
}

if (is_null($classroom_id)) {
    echo json_encode(["status" => false, "message" => "Could not determine classroom_id for assignment_id: $assignment_id"]);
    exit;
}

// Validate file upload
if ($_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(["status" => false, "message" => "File upload failed with error code: " . $_FILES['file']['error']]);
    exit;
}

// Validate file type (Only PDF)
$allowed_extensions = ['pdf'];
$file_name = $_FILES["file"]["name"];
$file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

if (!in_array($file_extension, $allowed_extensions)) {
    echo json_encode(["status" => false, "message" => "Invalid file type. Only PDF allowed."]);
    exit;
}

// Validate file size (Max: 10MB)
if ($_FILES["file"]["size"] > 10 * 1024 * 1024) { 
    echo json_encode(["status" => false, "message" => "File size exceeds 10MB limit."]);
    exit;
}

// Define upload directory
$upload_dir = "uploads/submissions/";

// Create directory if it doesn't exist
if (!is_dir($upload_dir) && !mkdir($upload_dir, 0777, true)) {
    echo json_encode(["status" => false, "message" => "Failed to create upload directory."]);
    exit;
}

// Generate unique file name
$file_path = $upload_dir . uniqid() . "_" . time() . ".pdf";

// Move uploaded file to directory
if (!move_uploaded_file($_FILES["file"]["tmp_name"], $file_path)) {
    echo json_encode(["status" => false, "message" => "Failed to move uploaded file."]);
    exit;
}

// Insert submission details into the database
$insertQuery = "INSERT INTO Submissions (assignment_id, id, classroom_id, file_url, marks, submitted_at) 
                VALUES (?, ?, ?, ?, NULL, NOW())";
$stmt = $conn->prepare($insertQuery);
$stmt->bind_param("iiis", $assignment_id, $id, $classroom_id, $file_path);

// Execute query
if ($stmt->execute()) {
    echo json_encode([
        "status" => true,
        "message" => "Assignment submitted successfully.",
        "data" => ["submission_id" => $stmt->insert_id]
    ]);
} else {
    echo json_encode(["status" => false, "message" => "Database error: " . $stmt->error]);
}

// Close statement and connection
$stmt->close();
$conn->close();
?>