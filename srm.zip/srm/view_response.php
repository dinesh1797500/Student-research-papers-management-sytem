<?php
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['assignment_id'])) {
        $assignment_id = intval($_GET['assignment_id']);

        $query = "SELECT file_data FROM Submissions WHERE assignment_id = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("i", $assignment_id);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($file_data);

        if ($stmt->fetch()) {
            header('Content-Type: application/pdf');
            echo $file_data;
            exit;
        } else {
            echo json_encode([
                "status" => false,
                "message" => "No submissions found for the given assignment ID.",
                "data" => []
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Missing assignment ID.",
            "data" => []
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method.",
        "data" => []
    ]);
}
?>
