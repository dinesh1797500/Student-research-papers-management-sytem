<?php
header('Content-Type: application/json');
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Secure query using prepared statements
    $sql = "SELECT id, name, email, password, role FROM users WHERE email = ? AND password = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $name, $email_db, $password_db, $role);
        $stmt->fetch();

        echo json_encode([
            "status" => true,
            "message" => "Login successful.",
            "data" => [
                [
                    "id" => $id,
                    "name" => $name,
                    "email" => $email_db,
                    "role" => $role
                ]
            ]
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Invalid email or password.",
            "data" => []
        ]);
    }

    $stmt->close();
}
$conn->close();
?>