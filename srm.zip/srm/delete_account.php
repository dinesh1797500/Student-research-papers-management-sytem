<?php
header('Content-Type: application/json');


include 'db.php';


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];


    $sql = "SELECT password FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();


    if ($stmt->num_rows > 0) {
        $stmt->bind_result($stored_password);
        $stmt->fetch();


        if ($password === $stored_password) {
            $delete_sql = "DELETE FROM users WHERE email = ?";
            $delete_stmt = $conn->prepare($delete_sql);
            $delete_stmt->bind_param("s", $email);


            if ($delete_stmt->execute()) {
                echo json_encode([
                    "status" => true,
                    "message" => "Account deleted successfully.",
                    "data" => []
                ]);
            } else {
                echo json_encode([
                    "status" => false,
                    "message" => "Error deleting account.",
                    "data" => []
                ]);
            }
            $delete_stmt->close();
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Invalid password.",
                "data" => []
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Account not found.",
            "data" => []
        ]);
    }


    $stmt->close();
}
$conn->close();
?>
