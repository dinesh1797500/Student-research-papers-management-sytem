<?php
include 'db.php'; // Include database connection

header('Content-Type: application/json');

session_start(); 

if (!isset($_SESSION['id'])) {
    // Still return all assignments but without submission details
    $_SESSION['id'] = 0; // Assign a dummy value to prevent SQL errors
}

$id = $_SESSION['id']; // Student's ID from session
$class_id = isset($_GET['class_id']) ? intval($_GET['class_id']) : 0;

if ($class_id == 0) {
    echo json_encode(["assignments" => []]); // Return empty list for invalid class ID
    exit;
}

// Fetch all assignments of the class
$query = "
    SELECT a.id AS assignment_id, a.title, a.description, a.due_date, 
           s.file_url AS submitted_file, s.marks
    FROM assignments a
    LEFT JOIN submissions s 
        ON a.id = s.assignment_id AND s.id = ?
    WHERE a.class_id = ?
    ORDER BY a.due_date DESC
";

$stmt = $conn->prepare($query);
$stmt->bind_param("ii", $id, $class_id);
$stmt->execute();
$result = $stmt->get_result();

$assignments = [];

while ($row = $result->fetch_assoc()) {
    $assignments[] = [
        "assignment_id" => $row['assignment_id'],
        "title" => $row['title'],
        "description" => $row['description'],
        "due_date" => $row['due_date'],
        "marks" => $row['submitted_file'] ? $row['marks'] : null, // Show marks only if submitted
    ];
}

echo json_encode(["assignments" => $assignments]);

$stmt->close();
$conn->close();
?>
