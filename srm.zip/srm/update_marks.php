<?php
include 'db.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['assignment_id'], $_POST['id'], $_POST['marks'])) {
        $assignment_id = intval($_POST['assignment_id']);
        $id = intval($_POST['id']);
        $marks = intval($_POST['marks']);

        $checkQuery = "SELECT id FROM Submissions WHERE assignment_id = ? AND id = ?";
        $stmt = $conn->prepare($checkQuery);
        $stmt->bind_param("ii", $assignment_id, $id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $updateQuery = "UPDATE Submissions SET marks = ? WHERE assignment_id = ? AND id = ?";
            $stmt = $conn->prepare($updateQuery);
            $stmt->bind_param("iii", $marks, $assignment_id, $id);

            if ($stmt->execute()) {
                echo json_encode([
                    "status" => true,
                    "message" => "Marks updated successfully."
                ]);
            } else {
                echo json_encode([
                    "status" => false,
                    "message" => "Failed to update marks."
                ]);
            }
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Submission not found."
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Missing required fields."
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method."
    ]);
}
?>
