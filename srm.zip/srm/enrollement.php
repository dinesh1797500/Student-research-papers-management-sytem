<?php
include 'db.php';  
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['id'], $_POST['class_code']) && !empty($_POST['id']) && !empty($_POST['class_code'])) {
        $id = intval($_POST['id']);
        $class_code = trim($_POST['class_code']);

        $checkClassQuery = "SELECT classroom_id FROM Classrooms WHERE class_code = ? LIMIT 1";
        $stmt = $conn->prepare($checkClassQuery);
        $stmt->bind_param("s", $class_code);
        $stmt->execute();
        $classResult = $stmt->get_result();

        if ($classResult->num_rows === 0) {
            echo json_encode(["status" => false, "message" => "Invalid class code."]);
            exit();
        }

        $classroom = $classResult->fetch_assoc();
        $classroom_id = $classroom['classroom_id'];
        $checkUserQuery = "SELECT role FROM Users WHERE id = ?";
        $stmt = $conn->prepare($checkUserQuery);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $userResult = $stmt->get_result();
        
        if ($userResult->num_rows > 0) {
            $user = $userResult->fetch_assoc();
            if ($user['role'] !== 'student') {
                echo json_encode(["status" => false, "message" => "Only students can join a class."]);
                exit();
            }
        } else {
            echo json_encode(["status" => false, "message" => "User not found."]);
            exit();
        }
        $checkEnrollmentQuery = "SELECT s_no FROM Enrollments WHERE id = ? AND classroom_id = ?";
        $stmt = $conn->prepare($checkEnrollmentQuery);
        $stmt->bind_param("ii", $id, $classroom_id);
        $stmt->execute();
        $enrollmentResult = $stmt->get_result();

        if ($enrollmentResult->num_rows > 0) {
            echo json_encode(["status" => false, "message" => "Student is already enrolled in this class."]);
            exit();
        }

        $insertQuery = "INSERT INTO Enrollments (id, classroom_id, joined_at) VALUES (?, ?, NOW())";
        $stmt = $conn->prepare($insertQuery);
        $stmt->bind_param("ii", $id, $classroom_id);

        if ($stmt->execute()) {
            echo json_encode([
                "status" => true,
                "message" => "Student enrolled successfully.",
                "data" => [
                    "id" => $id,
                    "classroom_id" => $classroom_id
                ]
            ]);
        } else {
            echo json_encode(["status" => false, "message" => "Failed to enroll student."]);
        }
        exit();
    } else {
        echo json_encode(["status" => false, "message" => "Missing id or class_code."]);
        exit();
    }
} else {
    echo json_encode(["status" => false, "message" => "Invalid request method."]);
    exit();
}
?>
