<?php
header('Content-Type: application/json');
include 'db.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if required fields are set
$user_id = isset($_POST['id']) ? $_POST['id'] : null;
$name = isset($_POST['name']) ? $_POST['name'] : null;
$phone = isset($_POST['phone']) ? $_POST['phone'] : null;
$email = isset($_POST['email']) ? $_POST['email'] : null;
$password = isset($_POST['password']) && !empty($_POST['password']) ? $_POST['password'] : null;

// Validate required fields
if (!$user_id || !$name || !$phone || !$email) {
    echo json_encode([
        "status" => false,
        "message" => "Missing required fields (id, name, phone, email).",
        "data" => []
    ]);
    exit;
}

// Check if the user exists
$sql_check = "SELECT id FROM users WHERE id = ?";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("i", $user_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();

if ($result_check->num_rows == 0) {
    echo json_encode([
        "status" => false,
        "message" => "User not found.",
        "data" => []
    ]);
    exit;
}

// Update user profile (excluding role)
if ($password) {
    $sql = "UPDATE users SET name = ?, phone = ?, email = ?, password = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssi", $name, $phone, $email, $password, $user_id);
} else {
    $sql = "UPDATE users SET name = ?, phone = ?, email = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssi", $name, $phone, $email, $user_id);
}

if ($stmt->execute()) {
    // Fetch updated user data
    $sql_fetch = "SELECT id, name, role, phone, email FROM users WHERE id = ?";
    $stmt_fetch = $conn->prepare($sql_fetch);
    $stmt_fetch->bind_param("i", $user_id);
    $stmt_fetch->execute();
    $result_fetch = $stmt_fetch->get_result();
    $updated_user = $result_fetch->fetch_assoc();

    echo json_encode([
        "status" => true,
        "message" => "Profile updated successfully.",
        "data" => $updated_user
    ]);

    $stmt_fetch->close();
} else {
    echo json_encode([
        "status" => false,
        "message" => "Error updating profile: " . $stmt->error
    ]);
}

$stmt->close();
$conn->close();
?>
