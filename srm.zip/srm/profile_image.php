<?php

require 'db.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_FILES['profile_image']) && isset($_POST['id'])) {
        $id = intval($_POST['id']);  // Convert id to integer for safety
        $uploadDir = "uploads/"; // Folder where images will be stored

        // Debugging: Check if ID is received
        if (!$id) {
            echo json_encode(["status" => false, "message" => "Invalid user ID."]);
            exit;
        }

        // Ensure upload directory exists
        if (!is_dir($uploadDir) && !mkdir($uploadDir, 0777, true) && !is_dir($uploadDir)) {
            echo json_encode(["status" => false, "message" => "Failed to create upload directory."]);
            exit;
        }

        $allowedTypes = ['image/jpeg', 'image/png', 'image/jpg'];
        $fileType = $_FILES['profile_image']['type'];
        $fileSize = $_FILES['profile_image']['size'];
        $fileTmpName = $_FILES['profile_image']['tmp_name'];

        // Debugging: Check if the file is uploaded correctly
        if (!is_uploaded_file($fileTmpName)) {
            echo json_encode(["status" => false, "message" => "File upload error."]);
            exit;
        }

        // Validate file type
        if (!in_array($fileType, $allowedTypes)) {
            echo json_encode(["status" => false, "message" => "Invalid file type. Only JPG, JPEG, and PNG are allowed."]);
            exit;
        }

        // Validate file size (Max: 2MB)
        if ($fileSize > 2 * 1024 * 1024) {
            echo json_encode(["status" => false, "message" => "File size too large. Max 2MB allowed."]);
            exit;
        }

        // Generate a unique filename
        $fileExt = pathinfo($_FILES['profile_image']['name'], PATHINFO_EXTENSION);
        $fileName = "profile_" . $id . "_" . time() . "." . $fileExt;
        $filePath = $uploadDir . $fileName; // Relative path (e.g., uploads/profile_xxx.jpg)

        // Move uploaded file
        if (move_uploaded_file($fileTmpName, $filePath)) {
            // Prepare statement to update database
            $stmt = $conn->prepare("UPDATE users SET profile_image = ? WHERE id = ?");
            if (!$stmt) {
                echo json_encode(["status" => false, "message" => "Database error: " . $conn->error]);
                exit;
            }

            $stmt->bind_param("si", $filePath, $id); // Store relative path only

            if ($stmt->execute()) {
                echo json_encode(["status" => true, "message" => "Profile updated successfully", "image_url" => $filePath]);
            } else {
                echo json_encode(["status" => false, "message" => "Database update failed: " . $stmt->error]);
            }
        } else {
            echo json_encode(["status" => false, "message" => "Failed to upload file"]);
        }
    } else {
        echo json_encode(["status" => false, "message" => "Missing parameters"]);
    }
} else {
    echo json_encode(["status" => false, "message" => "Invalid request"]);
}

?>
