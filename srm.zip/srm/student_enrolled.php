<?php
include 'db.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if id is provided
    if (isset($_POST['id']) && !empty($_POST['id'])) {
        $id = intval($_POST['id']);

        // Debugging: Log received ID
        error_log("Received student ID: " . $id);

        // ✅ Corrected JOIN condition
        $query = "SELECT Enrollments.classroom_id, Classrooms.class_name
                  FROM Enrollments
                  INNER JOIN Classrooms ON Enrollments.classroom_id = Classrooms.classroom_id
                  WHERE Enrollments.id = ?";

        // Prepare statement
        if ($stmt = $conn->prepare($query)) {
            $stmt->bind_param("i", $id);
            $stmt->execute();
            $result = $stmt->get_result();

            $classes = [];
            while ($row = $result->fetch_assoc()) {
                $classes[] = [
                    "classroom_id" => $row["classroom_id"],
                    "class_name" => $row["class_name"]
                ];
            }

            echo json_encode([
                "status" => true,
                "message" => count($classes) > 0 ? "Classes fetched successfully." : "No enrolled classes found.",
                "data" => $classes
            ]);

            $stmt->close();
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Failed to prepare SQL query: " . $conn->error,
                "data" => []
            ]);
        }
    } else {
        echo json_encode([
            "status" => false,
            "message" => "Missing or empty id.",
            "data" => []
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method. Use POST.",
        "data" => []
    ]);
}
?>
