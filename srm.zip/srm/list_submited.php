<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

include 'db.php'; // Include database connection

header('Content-Type: application/json');

// Check for POST request
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(["status" => false, "message" => "Invalid request method. Use POST.", "data" => []]);
    exit;
}

// Check if assignment_id is provided
if (empty($_POST['assignment_id'])) {
    echo json_encode(["status" => false, "message" => "Missing required field: assignment_id", "data" => []]);
    exit;
}

// Get assignment_id from POST data
$assignment_id = intval($_POST['assignment_id']);

// Prepare SQL query to fetch students who submitted the assignment along with their PDFs
$query = "SELECT s.id AS submission_id, s.id, u.name, u.email, s.file_url, s.submitted_at, s.marks 
          FROM Submissions s
          JOIN Users u ON s.id = u.id
          WHERE s.assignment_id = ? AND s.file_url IS NOT NULL AND s.file_url <> ''";

$stmt = $conn->prepare($query);

if ($stmt === false) {
    echo json_encode(["status" => false, "message" => "Database query preparation failed: " . $conn->error, "data" => []]);
    exit;
}

$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$result = $stmt->get_result();

$students_submitted = [];

// Fetch results
while ($row = $result->fetch_assoc()) {
    // Assuming file_url is a direct path to the file
    $row['file_url'] = 'https://yourdomain.com/uploads/' . $row['file_url']; // Adjust URL as needed
    $students_submitted[] = $row;
}

// Return the list of students who have submitted along with their PDFs
echo json_encode([
    "status" => true,
    "message" => "Submitted students retrieved successfully.",
    "data" => $students_submitted
]);

// Close connection
$stmt->close();
$conn->close();
?>
