<?php
include 'db.php'; 
header('Content-Type: application/json');

// Log received GET parameters
error_log("Received GET parameters: " . json_encode($_GET));

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(["status" => false, "message" => "Invalid request method. Use GET.", "data" => []]);
    exit;
}

// Check if assignment_id is provided
if (!isset($_GET['assignment_id']) || empty($_GET['assignment_id'])) {
    echo json_encode([
        "status" => false,
        "message" => "Missing or empty assignment ID. Received: " . json_encode($_GET),
        "data" => []
    ]);
    exit;
}

$assignment_id = intval($_GET['assignment_id']);
error_log("Processed assignment_id: " . $assignment_id);

$query = "SELECT id, marks FROM Submissions WHERE assignment_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$result = $stmt->get_result();

$marks_data = [];
while ($row = $result->fetch_assoc()) {
    $marks_data[] = ["id" => $row['id'], "marks" => $row['marks']];
}

$stmt->close();
$conn->close();

if (!empty($marks_data)) {
    echo json_encode(["status" => true, "message" => "Marks retrieved successfully.", "data" => $marks_data]);
} else {
    echo json_encode(["status" => false, "message" => "No marks found for the given assignment ID.", "data" => []]);
}
?>
