<?php
header('Content-Type: application/json');
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!isset($_GET['id'])) {
        echo json_encode([
            "status" => false,
            "message" => "User ID is required.",
            "data" => []
        ]);
        exit;
    }

    $user_id = intval($_GET['id']); // Ensure the ID is an integer

    $sql = "SELECT id, name, role, phone, email, profile_image, password FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        echo json_encode([
            "status" => true,
            "message" => "User profile retrieved successfully.",
            "data" => $user
        ]);
    } else {
        echo json_encode([
            "status" => false,
            "message" => "User not found.",
            "data" => []
        ]);
    }

    $stmt->close();
}

$conn->close();
?>
