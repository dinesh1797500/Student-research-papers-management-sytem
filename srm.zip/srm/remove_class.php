<?php
include 'db.php';  // Ensure this file contains the database connection setup

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if student_id and classroom_id are provided in the request
    if (isset($_POST['student_id'], $_POST['classroom_id'])) {

        $student_id = intval($_POST['student_id']);
        $classroom_id = intval($_POST['classroom_id']);

        $checkEnrollmentQuery = "SELECT id FROM Enrollments WHERE student_id = ? AND classroom_id = ?";
        $stmt = $conn->prepare($checkEnrollmentQuery);
        $stmt->bind_param("ii", $student_id, $classroom_id);
        $stmt->execute();
        $enrollmentResult = $stmt->get_result();

        if ($enrollmentResult->num_rows === 0) {
            echo json_encode([
                "status" => false,
                "message" => "Enrollment not found.",
                "data" => []
            ]);
            exit();
        }

        $deleteQuery = "DELETE FROM Enrollments WHERE student_id = ? AND classroom_id = ?";
        $stmt = $conn->prepare($deleteQuery);
        $stmt->bind_param("ii", $student_id, $classroom_id);

        if ($stmt->execute()) {
            echo json_encode([
                "status" => true,
                "message" => "Enrollment removed successfully.",
                "data" => [
                    "student_id" => $student_id,
                    "classroom_id" => $classroom_id
                ]
            ]);
        } else {
            echo json_encode([
                "status" => false,
                "message" => "Failed to remove enrollment.",
                "data" => []
            ]);
        }

    } else {
        echo json_encode([
            "status" => false,
            "message" => "Missing student_id or classroom_id.",
            "data" => []
        ]);
    }
} else {
    echo json_encode([
        "status" => false,
        "message" => "Invalid request method.",
        "data" => []
    ]);
}
?>
